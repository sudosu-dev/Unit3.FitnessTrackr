export default function ActivitiesPage() {
  return (
    <>
      <h1>Activities</h1>
      <p>Imagine all the activities!</p>
    </>
  );
}
